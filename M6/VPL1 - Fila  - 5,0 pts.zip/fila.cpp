#include "fila.h"

struct No {
  int chave;
  No* proximo;
};

Fila::Fila() {
  // TODO
}

void Fila::Inserir(int k) {
  // TODO
}

void Fila::RemoverPrimeiro() {
  // TODO
}

int Fila::primeiro() const {
  return 0; // TODO
}

int Fila::ultimo() const {
  return 0; // TODO
}

int Fila::tamanho() const {
  return 0; // TODO
}