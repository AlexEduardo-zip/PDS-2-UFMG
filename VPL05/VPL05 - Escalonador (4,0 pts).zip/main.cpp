// NÃO ALTERE ESSA LINHA
#include "avaliacao_basica_escalonador.hpp"

int main() {


    //
    // Adicione seu código aqui e faça as demais alterações necessárias
    //
    

    return 0;
}