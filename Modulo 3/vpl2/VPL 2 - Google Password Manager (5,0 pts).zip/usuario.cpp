#include "usuario.hpp"

Usuario::Usuario(const std::string& login, const std::string& password) {
  // TODO: Implemente este metodo
}

std::string Usuario::getLogin() const {
  // TODO: Implemente este metodo
  return "";
}

std::string Usuario::getPassword() const {
  // TODO: Implemente este metodo
  return "";
}

void Usuario::setPassword(const std::string& password) {
  // TODO: Implemente este metodo
}

void Usuario::setLogin(const std::string& login) {
  // TODO: Implemente este metodo
}