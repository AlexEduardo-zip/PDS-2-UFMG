#include "produto.hpp"

int Produto::getQtd() const {
  // TODO: Implemente este metodo
  return 0;
}

float Produto::getValor() const {
  // TODO: Implemente este metodo
  return 0;
}